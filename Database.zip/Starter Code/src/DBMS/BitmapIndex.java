package DBMS;

import java.util.BitSet;
import java.util.HashMap;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;

public class BitmapIndex implements Serializable {
    public Map<String , BitSet> index;
    public String column;

    public BitmapIndex(String column) {
        this.index = new HashMap<>();
        this.column = column;
    }
    
   
}