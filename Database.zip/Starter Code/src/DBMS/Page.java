package DBMS;

import java.io.Serializable;
import java.util.ArrayList;

public class Page implements Serializable
{
	public  ArrayList<String[]> records ;

	    public Page() {
	        this.records = new ArrayList<>();
	    }

	    public boolean isFull() {
	        return records.size() >= DBApp.dataPageSize;
	    }

	    public void insert(String[] record) {
	        records.add(record);
	    }
	    public int size(){
	    	return records.size();
	    	
	    }
}
