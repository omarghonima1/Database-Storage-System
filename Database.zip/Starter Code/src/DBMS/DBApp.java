package DBMS;
import java.util.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

import org.junit.Test;

public class DBApp
{
	static int dataPageSize = 2;
	
	public static void createTable(String tableName, String[] columnsNames)
	{
		ArrayList<String> tableArray = new ArrayList<>();
		for(int i=0;i<columnsNames.length;i++){
		tableArray.add(columnsNames[i]);
		}
		
		Table table=new Table(tableName,tableArray);
		
		FileManager.storeTable(tableName, table);
		String logEntry = "Table created name:" + tableName + ",columnsNames:"+ Arrays.toString(columnsNames);

			table.log(logEntry);
		FileManager.storeTable(tableName,table);
	}
	
	public static void insert(String tableName, String[] record)
	{
		 long startTime = System.currentTimeMillis();  
		Table table = FileManager.loadTable(tableName);
		int newPageIndex= 0;
	    boolean inserted = false;
	    int i =0;
	    if (table== null) {throw new RuntimeException("Table" + tableName + " does not exist."); }
	    else{
	       
	    
	    // 2. Loop through existing pages to find space
	    for ( i = 0; i < table.pagesArray.size(); i++) {
	        Page page = FileManager.loadTablePage(tableName, i);  // load page from disk

	        if (!page.isFull()) {
	            page.insert(record);  // insert record
	            FileManager.storeTablePage(tableName, i, page);  // store updated page
	            inserted = true;
	            newPageIndex = table.pagesArray.size() - 1;
	            break;
	            
	        }
	    }

	    // 3. If all pages are full, create a new page
	    if (!inserted | table.pagesArray == null) {
	    
	        Page newPage = new Page();
	        newPage.insert(record);
	        table.pagesArray.add(newPage);  // add page to table
	        newPageIndex = table.pagesArray.size() - 1;
	       	
	        
	        FileManager.storeTablePage(tableName, newPageIndex, newPage);  // save new page
	    }

	    // 4. Log and store table
	    long endTime = System.currentTimeMillis();    //  End time
	    long duration = endTime - startTime;
	     
	   
	    FileManager.storeTable(tableName, table); 
	    String logEntry = "Inserted:"  + Arrays.toString(record)+ ",at page number:"+ newPageIndex + ",execution time (mil):" + duration ;

	    for(int z=0;z<table.columnNames.size();z++){
	    	BitmapIndex bitmap = FileManager.loadTableIndex(tableName, table.columnNames.get(z));
	    	if(bitmap != null)
	    	createBitMapIndex(tableName, table.columnNames.get(z));
	    }
	    table.log(logEntry);
	    FileManager.storeTable(tableName, table); }
		
}
	
	
	
	public static ArrayList<String []> select(String tableName)
	{ long startTime = System.currentTimeMillis();  
		Table table	=FileManager.loadTable(tableName);
		 if (table== null) {throw new RuntimeException("Table" + tableName + " does not exist."); }
		    else{
		ArrayList<String[]> res = new ArrayList<>();
		int e=0;
		ArrayList<Page> tempPageArray = table.pagesArray;
		int j = 0;
		for(int i=0;i<tempPageArray.size();i++){
			
			Page tempPage = FileManager.loadTablePage(tableName, i);
			if(i!=0){
				e=e+dataPageSize;
			}
			for(j = 0; j< tempPage.size();j++){
				 res.add(tempPage.records.get(j));	 
			}
			FileManager.storeTablePage(tableName, i, tempPage);
			
		}
		int x=e+j;
		 long endTime = System.currentTimeMillis();    //  End time
		 long duration = endTime - startTime;
		FileManager.storeTable(tableName, table);
		String logEntry ="Select all pages:"+tempPageArray.size()+",records:"+x+",execution time (mil):" + duration;


		table.log(logEntry);
		FileManager.storeTable(tableName, table); 
		return res;}
	}
	
	public static ArrayList<String []> select(String tableName, int pageNumber, int recordNumber)
	{ long startTime = System.currentTimeMillis(); 
		Table table	=FileManager.loadTable(tableName);
		 if (table== null) {throw new RuntimeException("Table" + tableName + " does not exist."); }
		    else{
		ArrayList<String[]> res = new ArrayList<>();
		
		ArrayList<Page> tempPageArray = table.pagesArray;
		Page tempPage = new Page();
		
		for(int i=0;i<tempPageArray.size();i++){ 
			
			tempPage = FileManager.loadTablePage(tableName, i);
			for(int j = 0; j< tempPage.size();j++){
				
				if (i==pageNumber&& j==recordNumber ){
				 res.add(tempPage.records.get(j));	} 
				FileManager.storeTablePage(tableName, i, tempPage);
			}
		}
		
		long endTime = System.currentTimeMillis();    //  End time
	    long duration = endTime - startTime;
	    FileManager.storeTable(tableName, table);
	    String logEntry = "Select pointer page:"+pageNumber +", record:"+ recordNumber +",total output count:1"+",execution time (mil):"+ duration ;

	    table.log(logEntry);
		FileManager.storeTable(tableName, table); 
	
		return res;}
	}
	
	
	public static ArrayList<String []> select(String tableName, String[] cols, String[] vals)
    {long startTime = System.currentTimeMillis();
  
    ArrayList<Integer> currentPages = new ArrayList<>();
    Map<Integer, Integer> recordsPerPage = new HashMap<>();
        Table table  =FileManager.loadTable(tableName);
        if (table== null) {throw new RuntimeException("Table" + tableName + " does not exist."); }
	    else{
        ArrayList<String[]> res = new ArrayList<>();
        int r=0;
        
        int y=0;
        StringBuilder sb = new StringBuilder();
        ArrayList<Integer> index= new ArrayList<>();
        
        for(int i =0; i<cols.length;i++){
            for(int j=0;j<table.columnNames.size();j++){
                if(cols[i].equals(table.columnNames.get(j))){ 

                	 index.add(table.columnNames.indexOf(cols[i]));
                }
            }
        }
                	 ArrayList<Page> tempPageArray = table.pagesArray;
                	 
                    for( r=0;r<tempPageArray.size();r++){
                    Page tempPage = FileManager.loadTablePage(tableName, r);

                       for( y = 0; y< tempPage.size();y++){
                    	   
                           
                           String[] record = tempPage.records.get(y);
                           boolean flag = false;
                        	  for(int x=0;x<index.size();x++){
                        		  
                        		 
                        		  if(record[index.get(x)].equals(vals[x])){
                        			  flag= true;
                        		  }else{
                        			  flag = false;
                        			  break;
                        		  }
                        	  
                        	  }
                           if(flag == true){
                               res.add(record);
                               currentPages.add(r);
                              
                            // Track how many matched records were found in each page
                               recordsPerPage.put(r, recordsPerPage.getOrDefault(r, 0) + 1);

                           }

                       
                   
           }
                       FileManager.storeTablePage(tableName, r, tempPage); }
    
                    sb.append("[");
                    int counter = 0;
                    for (Map.Entry<Integer, Integer> entry : recordsPerPage.entrySet()) {
                        sb.append("[")
                          .append(entry.getKey()).append(", ")
                          .append(entry.getValue()).append("]");
                        if (counter < recordsPerPage.size() - 1)
                            sb.append(", ");
                        counter++;
                    }
                    sb.append("]"); // CLOSE the outer list
       
       
        
        long endTime = System.currentTimeMillis();    //  End time
	    long duration = endTime - startTime;
	    FileManager.storeTable(tableName, table); 
	    String logEntry = "Select condition: " + Arrays.toString(cols) + "->" + Arrays.toString(vals) + 
	            ",Records per page: " + sb + ",records:"+ res.size()+
	            ",execution time (mil):" + duration;
	    table.log(logEntry);
	   
	    FileManager.storeTable(tableName, table); 
        return res;}
    }
	
	public static String getFullTrace(String tableName) {
	    int y = 0;
	    int i = 0;
	    Table table = FileManager.loadTable(tableName);
	    ArrayList<Page> tempPageArray = table.pagesArray;

	    for (i = 0; i < tempPageArray.size(); i++) {
	        if (i + 1 == tempPageArray.size()) {
	            Page lastpage = FileManager.loadTablePage(tableName, i);
	            if (lastpage != null) {
	                y += lastpage.size();
	            } else {
	                System.err.println("Warning: Failed to load last page at index " + i);
	            }
	        } else {
	            y += dataPageSize;
	        }
	    }

	    // Get indexed columns
	    ArrayList<String> indexedCols = new ArrayList<>();
	    for (String colName : table.columnNames) {
	        BitmapIndex idx = FileManager.loadTableIndex(tableName, colName);
	        if (idx != null) {
	            indexedCols.add(colName);
	        }
	    }

	    // Build log
	    StringBuilder logBuilder = new StringBuilder();
	    logBuilder.append("Pages Count: ").append(i)
	              .append(", Records Count: ").append(y)
	              .append(", Indexed Columns: [");

	    for (int j = 0; j < indexedCols.size(); j++) {
	        logBuilder.append(indexedCols.get(j));
	        if (j < indexedCols.size() - 1) {
	            logBuilder.append(", ");
	        }
	    }
	    logBuilder.append("]");

	    table.log(logBuilder.toString());

	    // Build trace string
	    StringBuilder sb = new StringBuilder();
	    for (String log : table.trace) {
	        sb.append(log).append("\n");
	    }
	    return sb.toString().trim(); // remove final newline
	}

	
	public static String getLastTrace(String tableName)
	{
		String LastLine= null;
		Table table = FileManager.loadTable(tableName);
		ArrayList<String> z = table.trace;	
		for(int i=0;i<z.size();i++){
		 LastLine=z.get(i);
			
		}
			

		return LastLine;
	}
	
	public static ArrayList<String[]> validateRecords(String tableName) {
		 Table table = FileManager.loadTable(tableName);
		    ArrayList<String[]> missingRecords = new ArrayList<>();
		    int x=0;
		    if (table == null) {
		        throw new RuntimeException("Table " + tableName + " does not exist.");
		    }

		    // Step 1: Parse inserted records from the log
		    ArrayList<String[]> insertedRecords = new ArrayList<>();
		    for (String logEntry : table.trace) {
		        if (logEntry.startsWith("Inserted:")) {
		            try {
		                String recordPart = logEntry.substring(logEntry.indexOf("[") + 1, logEntry.indexOf("]"));
		                String[] fields = recordPart.split(",\\s*");
		                insertedRecords.add(fields);
		            } catch (Exception e) {
		                System.err.println("Failed to parse log entry: " + logEntry);
		            }
		        }
		    }

		    // Step 2: Collect all records currently in the table
		    ArrayList<String[]> currentRecords = new ArrayList<>();
		    for (int i = 0; i < table.pagesArray.size(); i++) {
		        Page page = FileManager.loadTablePage(tableName, i);
		        if (page != null) {
		            currentRecords.addAll(page.records);
		        } else {
		            System.err.println("Warning: Page " + i + " of table '" + tableName + "' is missing or failed to load.");
		        }
		    }

		    // Step 3: Find which inserted records are missing from current records
		    for (String[] inserted : insertedRecords) {
		        boolean found = false;
		        for (String[] current : currentRecords) {
		            if (Arrays.equals(inserted, current)) {
		                found = true;
		                break;
		            }
		        }
		        if (!found) {
		            missingRecords.add(inserted);
		            
		        }
		    }
		    
		   x= missingRecords.size();
		    
		    table.log("Validating records: " + x+ " records missing. " );

			FileManager.storeTable(tableName, table); 
		    return missingRecords;
	}


	public static void recoverRecords(String tableName, ArrayList<String[]> missing) {
	    Table table = FileManager.loadTable(tableName);
	    if (table == null)
	        throw new RuntimeException("Table " + tableName + " does not exist.");

	    Map<String, Integer> recordToPageMap = new HashMap<>();

	    // 1. Parse trace to find the original page of each missing record
	    for (String logEntry : table.trace) {
	        if (logEntry.startsWith("Inserted:")) {
	            try {
	                String recordPart = logEntry.substring(logEntry.indexOf("[") + 1, logEntry.indexOf("]"));
	                String[] fields = recordPart.split(",\\s*");

	                for (int i = 0; i < fields.length; i++) {
	                    fields[i] = fields[i].trim();
	                }

	                for (String[] missingRecord : missing) {
	                    if (Arrays.equals(fields, missingRecord)) {
	                        String pageMarker = "at page number:";
	                        if (logEntry.contains(pageMarker)) {
	                            String pageStr = logEntry.substring(logEntry.indexOf(pageMarker) + pageMarker.length());
	                            pageStr = pageStr.split(",")[0].trim();
	                            int pageNum = Integer.parseInt(pageStr);
	                            recordToPageMap.put(Arrays.toString(missingRecord), pageNum);
	                        }
	                    }
	                }
	            } catch (Exception e) {
	                System.err.println("Failed to parse log entry: " + logEntry);
	            }
	        }
	    }

	    // 2. Recover each record into its original page
	    Set<Integer> pagesUsed = new TreeSet<>();
	    int recoveredCount = 0;

	    for (String[] missingRecord : missing) {
	        Integer pageIndex = recordToPageMap.get(Arrays.toString(missingRecord));
	        if (pageIndex == null) {
	            System.err.println("No original page info found for: " + Arrays.toString(missingRecord));
	            continue;
	        }

	        Page page = FileManager.loadTablePage(tableName, pageIndex);
	        if (page == null) {
	            page = new Page();
	        }

	        if (!page.isFull()) {
	            page.insert(missingRecord);
	        } else {
	            boolean inserted = false;
	            for (int i = 0; i < page.records.size(); i++) {
	                String[] existing = page.records.get(i);
	                if (existing == null) {
	                    page.records.set(i, missingRecord);
	                    inserted = true;
	                    break;
	                }
	            }

	            if (!inserted) {
	                System.err.println("Original page " + pageIndex + " is full. Cannot recover: " + Arrays.toString(missingRecord));
	                continue;
	            }
	        }

	        FileManager.storeTablePage(tableName, pageIndex, page);
	        pagesUsed.add(pageIndex);
	        recoveredCount++;
	    }

	    // Final summary log
	    table.log("Recovering " + recoveredCount + " records in pages: " + pagesUsed);

	    FileManager.storeTable(tableName, table);
	}


	
	public static void createBitMapIndex(String tableName, String  colName){
		long startTime = System.currentTimeMillis();
		 int globalIndex = 0;
			BitmapIndex bitmap = new BitmapIndex(colName);
			 Table table = FileManager.loadTable(tableName);
			 ArrayList<String> columns = table.columnNames;
			 int colIndex=0;
			 for(int i=0;i<columns.size();i++){
				if(columns.get(i).equals(colName)){
					break;
				}
				colIndex++;
			 }

			 for(int i=0;i < table.pagesArray.size();i++){
				Page page = FileManager.loadTablePage(tableName, i);
				
				for(int j=0; j < page.size();j++){
					String[] record = page.records.get(j);
					String value = record[colIndex];
					
					
					if(bitmap.index.containsKey(value)){
						bitmap.index.get(value).set(globalIndex, true);
					}else{
						BitSet bitset = new BitSet();
						bitset.set(globalIndex, true);
						bitmap.index.put(value, bitset);
					}
					globalIndex++;

				}
			 }
			 FileManager.storeTableIndex(tableName, colName, bitmap);
			 
			 
			 
			 
			 
			    long endTime = System.currentTimeMillis();    //  End time
			    long duration = endTime - startTime;
			    table.log( "Index created for column: " +colName + ", execution time (mil):"+ duration);
			    FileManager.storeTable(tableName, table);
	}
	
	
	
	public static String getValueBits(String tableName, String colName, String value){
		 BitmapIndex bitmap = FileManager.loadTableIndex(tableName, colName);
		 Table table = FileManager.loadTable(tableName);
		 if(bitmap== null){
			 return "No bitmap index";
		 }
		 
		 
		 int length = 0;
		 for (int i=0;i<table.pagesArray.size();i++) {
			 Page page = FileManager.loadTablePage(tableName, i);
		     length += page.size();
		 }
		 
		 BitSet bitset = bitmap.index.get(value);
		 if(bitset == null){
			 char[] chars = new char[length];
			 Arrays.fill(chars, '0');
			 String zeros = new String(chars);
			 return zeros;
		 }
		 
		 StringBuilder sb = new StringBuilder(length);
		 for (int i = 0; i < length; i++) {
		     if (bitset.get(i)) {
		         sb.append('1');
		     } else {
		         sb.append('0');
		     }
		 }
		 return sb.toString();
		 
	}


	 
	public static ArrayList<String[]> selectIndex(String tableName, String[] cols, String[] vals) {
	    Table table = FileManager.loadTable(tableName);
	    long startTime = System.currentTimeMillis();
	    Map<String, BitmapIndex> availableIndexes = new HashMap<>();

	    for (String col : cols) {
	        BitmapIndex index = FileManager.loadTableIndex(tableName, col);
	        if (index != null) {
	            availableIndexes.put(col, index);
	        }
	    }

	    ArrayList<String[]> results = new ArrayList<>();
	    int indexedCount = 0;
	    int finalCount = 0;

	    if (availableIndexes.size() == cols.length) {
	        BitmapIndex firstBitmap = availableIndexes.get(cols[0]);
	        BitSet firstBitsRaw = firstBitmap.index.get(vals[0]);
	        if (firstBitsRaw == null) firstBitsRaw = new BitSet();
	        BitSet firstBits = (BitSet) firstBitsRaw.clone();

	        BitmapIndex secondBitmap = availableIndexes.get(cols[1]);
	        BitSet secondBitsRaw = secondBitmap.index.get(vals[1]);
	        if (secondBitsRaw == null) secondBitsRaw = new BitSet();
	        BitSet secondBits = (BitSet) secondBitsRaw.clone();

	        firstBits.and(secondBits);
	        indexedCount = firstBits.cardinality();

	        int recordCounter = 0;
	        for (int i = 0; i < table.pagesArray.size(); i++) {
	            Page page = FileManager.loadTablePage(tableName, i);
	            for (String[] record : page.records) {
	                if (firstBits.get(recordCounter)) {
	                    results.add(record);
	                }
	                recordCounter++;
	            }
	        }
	        finalCount = results.size();
	    }

	    else if (availableIndexes.isEmpty()) {
	        results = DBApp.select(tableName, cols, vals);
	        finalCount = results.size();
	    }

	    else {
	        BitSet combinedBitSet = null;
	        for (int i = 0; i < cols.length; i++) {
	            String col = cols[i];
	            String val = vals[i];

	            if (availableIndexes.containsKey(col)) {
	                BitmapIndex bitmap = availableIndexes.get(col);
	                BitSet bitset = bitmap.index.get(val);
	                if (bitset == null) continue;

	                if (combinedBitSet == null)
	                    combinedBitSet = (BitSet) bitset.clone();
	                else
	                    combinedBitSet.and(bitset);
	            }
	        }

	        if (combinedBitSet == null) {
	            results = DBApp.select(tableName, cols, vals);
	            finalCount = results.size();
	        } else {
	            indexedCount = combinedBitSet.cardinality();
	            int recordIndex = 0;
	            for (int f = 0; f < table.pagesArray.size(); f++) {
	                Page page = FileManager.loadTablePage(tableName, f);
	                for (String[] record : page.records) {
	                    if (combinedBitSet.get(recordIndex)) {
	                        boolean matches = true;
	                        for (int i = 0; i < cols.length; i++) {
	                            if (!availableIndexes.containsKey(cols[i])) {
	                                int colIndex = table.columnNames.indexOf(cols[i]);
	                                if (!record[colIndex].equals(vals[i])) {
	                                    matches = false;
	                                    break;
	                                }
	                            }
	                        }
	                        if (matches) results.add(record);
	                    }
	                    recordIndex++;
	                }
	            }
	            finalCount = results.size();
	        }
	    }

	    // Always log
	    long endTime = System.currentTimeMillis();
	    long duration = endTime - startTime;

	    StringBuilder sb = new StringBuilder();
	    sb.append("Select index condition:[");
	    for (int i = 0; i < cols.length; i++) {
	        sb.append(cols[i]);
	        if (i < cols.length - 1) sb.append(", ");
	    }
	    sb.append("]->[");
	    for (int i = 0; i < vals.length; i++) {
	        sb.append(vals[i]);
	        if (i < vals.length - 1) sb.append(", ");
	    }
	    sb.append("], ");

	    // Conditionally include indexed columns section
	    if (!availableIndexes.isEmpty()) {
	        sb.append("Indexed columns: [");
	        int indexCount = 0;
	        for (String col : cols) {
	            if (availableIndexes.containsKey(col)) {
	                sb.append(col);
	                indexCount++;
	                if (indexCount < availableIndexes.size()) sb.append(", ");
	            }
	        }
	        sb.append("], ");
	    }

	    // Conditionally include non-indexed columns section
	    if (availableIndexes.size() < cols.length) {
	        sb.append("Non Indexed: [");
	        boolean firstNon = true;
	        for (String col : cols) {
	            if (!availableIndexes.containsKey(col)) {
	                if (!firstNon) sb.append(", ");
	                sb.append(col);
	                firstNon = false;
	            }
	        }
	        sb.append("], ");
	    }

	    sb.append("Indexed selection count: ").append(indexedCount);
	    sb.append(", Final count: ").append(finalCount);
	    sb.append(", execution time (mil):").append(duration);

	    table.log(sb.toString());
	    FileManager.storeTable(tableName, table);

	    return results;
	}


	
	 public static void main(String []args) throws IOException 
	 { 
	 FileManager.reset(); 
	 String[] cols = {"id","name","major","semester","gpa"}; 
	 createTable("student", cols); 
	 String[] r1 = {"1", "stud1", "CS", "5", "0.9"}; 
	 insert("student", r1); 
	  
	  
	    
	   String[] r2 = {"2", "stud2", "BI", "7", "1.2"}; 
	   insert("student", r2); 
	    
	   String[] r3 = {"3", "stud3", "CS", "2", "2.4"}; 
	   insert("student", r3); 
	    
	   createBitMapIndex("student", "gpa"); 
	   createBitMapIndex("student", "major"); 
	    
	   System.out.println("Bitmap of the value of CS from the major index: "+getValueBits("student", "major", "CS")); 
	   System.out.println("Bitmap of the value of 1.2 from the gpa index:  "+getValueBits("student", "gpa", "1.2")); 
	    
	    
	   String[] r4 = {"4", "stud4", "CS", "9", "1.2"}; 
	   insert("student", r4); 
	    
	   String[] r5 = {"5", "stud5", "BI", "4", "3.5"}; 
	   insert("student", r5); 
	    
	   System.out.println("After new insertions:");  
	   System.out.println("Bitmap of the value of CS from the major index:  "+getValueBits("student", "major", "CS")); 
	   System.out.println("Bitmap of the value of 1.2 from the gpa index: "+getValueBits("student", "gpa", "1.2")); 
	      
	    
	   System.out.println("Output of selection using index when all columns of the select conditions are indexed:"); 
	   ArrayList<String[]> result1 = selectIndex("student", new String[] 
	 {"major","gpa"}, new String[] {"CS","1.2"}); 
	         for (String[] array : result1) { 
	             for (String str : array) { 
	                 System.out.print(str + " "); 
	             } 
	             System.out.println(); 
	         } 
	   System.out.println("Last trace of the table: "+getLastTrace("student")); 
	         System.out.println("--------------------------------"); 
	          
	   System.out.println("Output of selection using index when only one column  of the columns of the select conditions are indexed:"); 
	   ArrayList<String[]> result2 = selectIndex("student", new String[] 
	 {"major","semester"}, new String[] {"CS","5"}); 
	         for (String[] array : result2) { 
	             for (String str : array) { 
	                 System.out.print(str + " "); 
	             } 
	             System.out.println(); 
	         } 
	   System.out.println("Last trace of the table: "+getLastTrace("student")); 
	         System.out.println("--------------------------------"); 
	          
	 System.out.println("Output of selection using index when some of the columns  of the select conditions are indexed:"); 
	 ArrayList<String[]> result3 = selectIndex("student", new String[] 
	 {"major","semester","gpa" }, new String[] {"CS","5", "0.9"}); 
	 for (String[] array : result3) { 
	 for (String str : array) { 
	 System.out.print(str + " "); 
	 } 
	 System.out.println(); 
	 } 
	 System.out.println("Last trace of the table: "+getLastTrace("student")); 
	 System.out.println("--------------------------------"); 
	 System.out.println("Full Trace of the table:"); 
	 System.out.println(getFullTrace("student")); 
	 System.out.println("--------------------------------"); 
	 System.out.println("The trace of the Tables Folder:"); 
	 System.out.println(FileManager.trace()); 
	 }
	 
	 
	 
}