package DBMS;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class Table implements Serializable
{
	public	String name;
	 public   ArrayList<String> columnNames;
		public ArrayList<Page> pagesArray;
		 public ArrayList<String> trace;
		
		 
	    public Table(String name, ArrayList<String> columnNames) {
	        this.name = name;
	        this.columnNames = columnNames;
	        this.pagesArray = new ArrayList<>();
	        this.trace=new ArrayList<>();
	     

	        
	    }
	    public void log(String action) {
	    	trace.add(action);
	    	
	        
	    }
	    
	    
	    	
	    
	    
	    	
	    	
	    	
	    	
	    	 
	    	  
	    	  
	    	  
	      }
	    





